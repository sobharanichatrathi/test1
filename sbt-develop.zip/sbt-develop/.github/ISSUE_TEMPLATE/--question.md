---
name: "❓ Question"
about: Please use https://stackoverflow.com/questions/tagged/sbt for questions
title: ''
labels: ''
assignees: ''

---

Please use https://stackoverflow.com/questions/tagged/sbt for questions instead of posting them to the issue tracker.
