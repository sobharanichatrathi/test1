---
name: "\U0001F41B Bug report"
about: Create a report to help us improve
title: ''
labels: Bug
assignees: ''

---

## steps

<!-- Describe exact steps to reproduce your problems on our computer, including sbt version and build.sbt  -->

## problem

<!-- Next, describe the problem, or what you think is the problem. -->

## expectation

<!-- Describe what you think should've happened. -->

## notes
