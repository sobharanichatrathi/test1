[@liufengyun]: https://github.com/liufengyun

[4073]: https://github.com/sbt/sbt/issues/4073
[4084]: https://github.com/sbt/sbt/pull/4084


### Improvements

- Detect dotty plugins which have descriptor file named `plugin.properties` instead of `scalac-plugin.xml`.  [#4073][4073]/[#4084][4084] by [@liufengyun][@liufengyun]
