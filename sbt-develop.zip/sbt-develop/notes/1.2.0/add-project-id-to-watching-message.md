[@dwijnand]: https://github.com/dwijnand

[#2038]: https://github.com/sbt/sbt/issues/2038
[#3813]: https://github.com/sbt/sbt/pull/3813

### Fixes with compatibility implications

### Improvements

- Add the current project's id to `~`'s watching message.  [#2038][]/[#3813][] by [@dwijnand][]

### Bug fixes
