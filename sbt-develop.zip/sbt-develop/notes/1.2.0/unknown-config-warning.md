[@steinybot]: https://github.com/steinybot

[#4065]: https://github.com/sbt/sbt/issues/4065
[#4231]: https://github.com/sbt/sbt/pull/4231

### Improvements

- Add a warning for unknown project configurations.  [#4065][]/[#4231][] by [@steinybot][]
