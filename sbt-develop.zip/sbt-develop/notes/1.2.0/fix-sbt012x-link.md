### Bug fixes

* Fixes link to SBT upgrade migration page

