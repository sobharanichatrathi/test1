[@ruippeixotog]: https://github.com/gpoirier

[#2881]: https://github.com/sbt/sbt/issues/2881

### Improvements

- Adding minimal support for commands in inspect. There's also a special case for aliases.
