
[#3042]: https://github.com/sbt/sbt/issues/3042
[#4056]: https://github.com/sbt/sbt/pull/4056

### Introduce CompositeProject

### Improvements

- Support for: `lazy val foo = someCompositeProject` (e.g.`CrossProject`)  [#3042][]/[#4056][]
