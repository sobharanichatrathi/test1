[@ruippeixotog]: https://github.com/ruippeixotog

[#3698]: https://github.com/sbt/sbt/issues/3698
[#3995]: https://github.com/sbt/sbt/pull/3995

### Improvements

- Make `++ <scala-version> <command>` run `<command>` only on compatible subprojects. [#3698][]/[#3995][] by [@ruippeixotog][]
