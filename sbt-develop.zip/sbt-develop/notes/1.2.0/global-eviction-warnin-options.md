### Improvements

- Add the eviction warning options to global, so that one can change the options for all sub projects at a time.
