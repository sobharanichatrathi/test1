- `-Dsbt.offline=true` now can set offline mode.

