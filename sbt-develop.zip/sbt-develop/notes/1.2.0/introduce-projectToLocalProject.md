[@dwijnand]: https://github.com/dwijnand

[#3757]: https://github.com/sbt/sbt/issues/3757
[#3836]: https://github.com/sbt/sbt/pull/3836

### Fixes with compatibility implications

### Improvements

- Introduces `projectToLocalProject` to replace `projectToRef`.  [#3757][]/[#3836][] by [@dwijnand][]

### Bug fixes
