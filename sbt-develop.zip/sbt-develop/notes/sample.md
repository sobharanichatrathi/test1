[@dwijnand]: https://github.com/dwijnand

[2059]: https://github.com/sbt/sbt/issues/2059
[2662]: https://github.com/sbt/sbt/pull/2662

### Fixes with compatibility implications

### Improvements

- Changes `publishTo` and `otherResolvers` from SettingKeys to TaskKeys. [#2059][2059]/[#2662][2662] by [@dwijnand][@dwijnand]

### Bug fixes
