[@muuki88]: https://github.com/muuki88
[@gutefrageIT]: https://twitter.com/gutefrageIT

[#1972]: https://github.com/sbt/sbt/issues/1972
[#4329]: https://github.com/sbt/sbt/pull/4329

### Bug Fixes

- Enable packaging of the same file more than once  [#1972][]/[#4329][] by [@muuki88][] (sponsored by [@gutefrageIT][])
