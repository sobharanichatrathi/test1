[@yamachu]: https://github.com/yamachu

[#5047]: https://github.com/sbt/sbt/issues/5047
[#5048]: https://github.com/sbt/sbt/pull/5048

### Bug Fixes

- Enable file watching when setting relative path to sbt.global.base [#5047][5047]/[#5048][5048] by [@yamachu][@yamachu]
