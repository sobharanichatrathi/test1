package foo

object Hello extends App {
  println("hello")
}
