import verify._

object HelloTest extends BasicTestSuite {
  test("addition") {
    assert(2 == 1 + 1)
  }
}
