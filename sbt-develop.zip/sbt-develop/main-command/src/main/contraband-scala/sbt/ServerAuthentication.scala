/**
 * This code is generated using [[https://www.scala-sbt.org/contraband/ sbt-contraband]].
 */

// DO NOT EDIT MANUALLY
package sbt
sealed abstract class ServerAuthentication extends Serializable
object ServerAuthentication {
  
  
  case object Token extends ServerAuthentication
}
