object RootSpec
