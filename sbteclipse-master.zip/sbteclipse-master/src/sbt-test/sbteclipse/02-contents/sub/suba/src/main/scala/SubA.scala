object SubA {
  val logger = org.slf4j.LoggerFactory.getLogger("suba")
  def subA = "subA"
}
