object SubC {
  def subC = "subC"
}
